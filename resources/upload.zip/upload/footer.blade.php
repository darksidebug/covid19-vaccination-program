<footer class="text-center mb-4" style="margin-top:4em;">
<img style="filter:grayscale(100%);opacity:0.5" class="img-fluid mb-2" src="https://trace.southernleyte.org.ph/assets/img/ccsit-logo.png" width="50" height="50">
    <p class="text-muted" style="margin-bottom:0.2em"><strong>Automated Contact Tracing System</strong></p>
    <small>   
        <p class="text-muted mb-1"><a href="http://slsuonline.edu.ph" style="color:#6c757d!important">Southern Leyte State University - Main Campus</a></p>
        <p class="text-muted mb-0">Copyright © CCSIT | 2021</p>
        <!-- <p class="text-muted mt-0">Developed by <a href="https://facebook.com/doing.art.man" style="color:#6c757d!important">Arman M. Masangkay</a></p> -->
    </small>
</footer>